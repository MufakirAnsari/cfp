---
name: Story Card
about: 'A concrete piece of value added, ideally vertically sliced '
title: ''
labels: ''
assignees: ''

---

## Context
#### Overview

#### Out of Scope:
#### Related issues/Dependencies:

## Acceptance Criteria
- [ ] When ... then...

## Tech Tasks
- [ ] Add appropriate test coverage, including edge cases.
- [ ] Run Changesets, bump any packages that have been updated/changed
- [ ] Did you make changes to the client, api or cli package? If so, considering updating the create-app templates.
- [ ] If any create-app templates have been updated, make sure to run the [test-create-app script](https://docs.google.com/document/d/1Ei6Cb2DjwEJUNtpULJSxbOuIdAfCARERgE3BSsKWrsc/edit) to ensure it still works properly.

### Tech Notes

## Review Tasks
- [ ] eg. specific QA details, update methodology, or update microsite

