/*
 * © 2021 Thoughtworks, Inc.
 */

import appConfig, { ClientConfig } from './Config'

export default function config(): ClientConfig {
  return appConfig
}
