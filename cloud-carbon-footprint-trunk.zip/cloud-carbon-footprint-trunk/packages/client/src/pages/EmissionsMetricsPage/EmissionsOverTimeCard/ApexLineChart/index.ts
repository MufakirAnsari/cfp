/*
 * © 2021 Thoughtworks, Inc.
 */

export { default } from './ApexLineChart'
