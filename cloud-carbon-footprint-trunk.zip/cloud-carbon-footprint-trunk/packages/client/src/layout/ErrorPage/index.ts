/*
 * © 2021 Thoughtworks, Inc.
 */

export { default, useAxiosErrorHandling } from './ErrorPage'
