/*
 * © 2021 Thoughtworks, Inc.
 */

import cli from './cli'
import * as console from 'console'

cli().then(console.log)
