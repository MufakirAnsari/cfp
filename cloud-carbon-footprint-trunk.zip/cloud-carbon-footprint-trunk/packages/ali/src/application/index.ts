/*
 * © 2023 Thoughtworks, Inc.
 */
export { default as AliAccount } from './AliAccount'
