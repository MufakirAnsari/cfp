/*
 * © 2023 Thoughtworks, Inc.
 */
export {
  ALI_EMISSIONS_FACTORS_METRIC_TON_PER_KWH,
  ALI_CLOUD_CONSTANTS,
} from './AliFootprintEstimationConstants'
