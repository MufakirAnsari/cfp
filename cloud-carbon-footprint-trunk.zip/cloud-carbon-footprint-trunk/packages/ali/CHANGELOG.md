# @cloud-carbon-footprint/ali

## 0.1.3

### Patch Changes

- 7d527d28: updates ramda dep
- Updated dependencies [db1b66fe]
  - @cloud-carbon-footprint/common@1.13.1

## 0.1.2

### Patch Changes

- dd98c8cb: Enables Ali Cloud ECS estimates in the CCF Application
- Updated dependencies [bc06b861]
- Updated dependencies [7630768d]
- Updated dependencies [6ffe7497]
  - @cloud-carbon-footprint/common@1.13.0

## 0.1.1

### Patch Changes

- fc4a1c93: Fixes package.json description for initial release
