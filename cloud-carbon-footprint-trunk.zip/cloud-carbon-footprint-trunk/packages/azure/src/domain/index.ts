export {
  AZURE_EMISSIONS_FACTORS_METRIC_TON_PER_KWH,
  AZURE_CLOUD_CONSTANTS,
} from './AzureFootprintEstimationConstants'
