/*
 * © 2021 Thoughtworks, Inc.
 */

export { default as ConsumptionManagementService } from './ConsumptionManagement'
