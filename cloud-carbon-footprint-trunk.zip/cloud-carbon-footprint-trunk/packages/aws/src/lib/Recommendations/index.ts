/*
 * © 2021 Thoughtworks, Inc.
 */

export { default as RightsizingRecommendations } from './RightsizingRecommendations'
export { default as ComputeOptimizerRecommendations } from './ComputeOptimizerRecommendations'
export { default as Recommendations } from './Recommendations'
