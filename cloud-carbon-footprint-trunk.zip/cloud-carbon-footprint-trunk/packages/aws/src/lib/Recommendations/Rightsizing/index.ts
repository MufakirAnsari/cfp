/*
 * © 2021 Thoughtworks, Inc.
 */

export { default as RightsizingRecommendation } from './RightsizingRecommendation'
export { default as RightsizingCurrentRecommendation } from './RightsizingCurrentRecommendation'
export { default as RightsizingTargetRecommendation } from './RightsizingTargetRecommendation'
