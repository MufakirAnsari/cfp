---
'@cloud-carbon-footprint/create-app': patch
---

updates the cli scripts
