# 14. Cache File store on Google cloud Storage

Date: 2021-05-26

## Status

Accepted

## Decision 

— Adding feature to store cache file on Google Cloud Storage

## Context 

— Cache file now has two options to be stored (locally and Google Clous Storage)

## Consequences 

— The app won't write a local file anymore if GCS option is enabled


