# 1. Chart library

Date: 2020-08-27

## Status

Accepted

## Decision 

ApexCharts was chosen

## Context 

We need a chart library for data visualization. ApexCharts provides a wide
amount of charts with extended behavior which covers initial business
requirements. Open source licence. React wrapper available.

## Consequences 

This library might not be as customizable as those based on D3. E.g. it does
not offer a geomap chart.

