# 13. Create App

Date: 2021-04-12

## Status

Accepted

## Context

## Decision

Adding the create app package allows users to directly install the npm
published package to have a quick start into local development. The user will
be guided through a quick installation and have their own ccf app created.

## Consequences
