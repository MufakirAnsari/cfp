# 7. Filters api

Date: 2021-03-02

## Status

Accepted

## Decision 

— creating a filter api

## Context 

— this was created to prevent duplication of the env file for clients to use if choosing the dashboard

## Consequences 

— this couples the server

